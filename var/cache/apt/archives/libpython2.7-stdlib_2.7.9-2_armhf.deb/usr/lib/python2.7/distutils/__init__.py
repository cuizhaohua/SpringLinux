"""distutils

The main package for the Python Module Distribution Utilities.  Normally
used from a setup script as

   from distutils.core import setup

   setup (...)
"""

__revision__ = "$Id$"

# Distutils version
#
# Updated automatically by the Python release process.
#
#--start constants--
__version__ = "2.7.9"
#--end constants--
