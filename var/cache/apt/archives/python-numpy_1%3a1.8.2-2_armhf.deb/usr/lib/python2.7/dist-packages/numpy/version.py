
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.8.2'
version = '1.8.2'
full_version = '1.8.2'
git_revision = '4563730a2d036307f1b67b2856d749aabdd8d546'
release = True

if not release:
    version = full_version
